package com.wisnu.footballs.service

import com.wisnu.footballs.model.EventResponse
import com.wisnu.footballs.model.LeagueResponse
import com.wisnu.footballs.model.SearchResponse
import com.wisnu.footballs.model.TeamResponse
import kotlinx.coroutines.Deferred
import retrofit2.Call
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

interface ApiService {

    @GET("api/v1/json/1/search_all_leagues.php?s=Soccer")
    suspend fun getLeague(): Response<LeagueResponse>

    @GET("api/v1/json/1/eventspastleague.php")
    suspend fun getPrevEvent(@Query("id") id: String?): Response<EventResponse>

    @GET("api/v1/json/1/eventsnextleague.php")
    suspend fun getNextEvent(@Query("id") id: String?): Response<EventResponse>

    @GET("api/v1/json/1/lookupteam.php")
    suspend fun getTeamDetail(@Query("id") id: String?): Response<TeamResponse>

    @GET("api/v1/json/1/searchevents.php")
    suspend fun getSearch(@Query("e") e: String? ): Response<SearchResponse>
}
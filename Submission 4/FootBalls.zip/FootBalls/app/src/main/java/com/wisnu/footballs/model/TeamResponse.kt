package com.wisnu.footballs.model

data class TeamResponse(val teams: List<Team>)
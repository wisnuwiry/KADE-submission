package com.wisnu.footballs.presenter

import com.wisnu.footballs.api.ApiRepository
import com.wisnu.footballs.view.base.LeagueView
import kotlinx.coroutines.*
import retrofit2.HttpException

class LeaguePresenter(private val view: LeagueView) {

    private val service = ApiRepository.create()
    fun getData() {
        CoroutineScope(Dispatchers.IO).launch {
            val response = service.getLeague()
            withContext(Dispatchers.Default) {
                try {
                    if (response.isSuccessful) {
                        response.body()?.league?.let {
                            view.onSuccess(it)
                        }
                    } else {
                        view.onError("Error: " + response.code())
                    }
                } catch (e: HttpException) {
                    view.onError("Exception ${e.message()}")
                } catch (e: Throwable) {
                    view.onError("Ooops: Something else went wrong")
                }
            }
        }
    }
}
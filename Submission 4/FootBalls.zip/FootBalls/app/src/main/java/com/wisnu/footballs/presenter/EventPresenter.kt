package com.wisnu.footballs.presenter

import com.wisnu.footballs.api.ApiRepository
import com.wisnu.footballs.view.base.EventView
import kotlinx.coroutines.*
import retrofit2.HttpException

class EventPresenter(private val view: EventView) {
    private val service = ApiRepository.create()

    fun getPrev(id: String) {
        CoroutineScope(Dispatchers.IO).launch {
            val response = service.getPrevEvent(id)

            withContext(Dispatchers.Default) {
                try {
                    if (response.isSuccessful) {
                        response.body()?.events?.let {
                            view.onSuccess(it)
                        }
                    } else {
                        view.onError("Error: " + response.code())
                    }
                } catch (e: HttpException) {
                    view.onError("Exception ${e.message()}")
                } catch (e: Throwable) {
                    view.onError("Ooops: Something else went wrong")
                }
            }
        }
    }

    fun getNext(id: String) {
        CoroutineScope(Dispatchers.IO).launch {
            val response = service.getNextEvent(id)

            withContext(Dispatchers.Default) {
                try {
                    if (response.isSuccessful) {
                        response.body()?.events?.let {
                            view.onSuccess(it)
                        }
                    } else {
                        view.onError("Error: " + response.code())
                    }
                } catch (e: HttpException) {
                    view.onError("Exception ${e.message()}")
                } catch (e: Throwable) {
                    view.onError("Ooops: Something else went wrong")
                }
            }
        }
    }

    fun search(q: String?) {
        CoroutineScope(Dispatchers.IO).launch {
            val response = service.getSearch(q)

            withContext(Dispatchers.Default) {
                try {
                    if (response.isSuccessful) {
                        response.body()?.events?.let { it ->
                            val data = it.filter { it.strSport == "Soccer" }
                            view.onSuccess(data)
                        }
                    } else {
                        view.onError("Error: " + response.code())
                    }
                } catch (e: HttpException) {
                    view.onError("Exception ${e.message()}")
                } catch (e: Throwable) {
                    view.onError("Oops: Something else went wrong")
                }
            }
        }
    }
}
package com.wisnu.footballs.presenter

import com.wisnu.footballs.api.ApiRepository
import com.wisnu.footballs.view.base.EventDetailView
import kotlinx.coroutines.*
import retrofit2.HttpException

class EventDetailPresenter(private val view: EventDetailView) {
    private val service = ApiRepository.create()

    fun getHomeTeam(homeTeamId: String) {
        CoroutineScope(Dispatchers.IO).launch {
            val response = service.getTeamDetail(homeTeamId)
            withContext(Dispatchers.Default) {
                try {
                    if (response.isSuccessful) {
                        response.body()?.teams?.let {
                            view.dataHome(it[0])
                        }
                    } else {
                        view.onError("Error: " + response.code())
                    }
                } catch (e: HttpException) {
                    view.onError("Exception ${e.message()}")
                } catch (e: Throwable) {
                    view.onError("Ooops: Something else went wrong")
                }
            }
        }
    }

    fun getAwayTeam(awayTeamId: String) {
        CoroutineScope(Dispatchers.IO).launch {
            val response = service.getTeamDetail(awayTeamId)
            withContext(Dispatchers.Default) {
                try {
                    if (response.isSuccessful) {
                        response.body()?.teams?.let {
                            view.dataHome(it[0])
                        }
                    } else {
                        view.onError("Error: " + response.code())
                    }
                } catch (e: HttpException) {
                    view.onError("Exception ${e.message()}")
                } catch (e: Throwable) {
                    view.onError("Ooops: Something else went wrong")
                }
            }
        }
    }
}
